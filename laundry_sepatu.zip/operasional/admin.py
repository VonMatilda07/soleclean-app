from django.contrib import admin
from .models import Service, Order, OrderItem

# Biar bisa input Sepatu langsung di halaman Order (Nested)
class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 1 # Jumlah baris kosong default

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('nama_pelanggan', 'whatsapp', 'status', 'tanggal_masuk')
    inlines = [OrderItemInline] # Masukkan tabel sepatu ke sini

# Daftarin sisanya
admin.site.register(Service)
admin.site.register(OrderItem)