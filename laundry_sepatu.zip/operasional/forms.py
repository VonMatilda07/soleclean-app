from django import forms
from .models import Order, OrderItem

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['nama_pelanggan', 'whatsapp']
        # Kita kasih styling dikit biar gak kaku
        widgets = {
            'nama_pelanggan': forms.TextInput(attrs={'class': 'w-full border p-2 rounded', 'placeholder': 'Nama Customer'}),
            'whatsapp': forms.TextInput(attrs={'class': 'w-full border p-2 rounded', 'placeholder': '08xxx'}),
        }

class OrderItemForm(forms.ModelForm):
    class Meta:
        model = OrderItem
        fields = ['service', 'merk_sepatu', 'warna', 'foto_sebelum', 'catatan']
        widgets = {
            'service': forms.Select(attrs={'class': 'w-full border p-2 rounded'}),
            'merk_sepatu': forms.TextInput(attrs={'class': 'w-full border p-2 rounded'}),
            'warna': forms.TextInput(attrs={'class': 'w-full border p-2 rounded'}),
            'catatan': forms.Textarea(attrs={'class': 'w-full border p-2 rounded', 'rows': 2}),
        }