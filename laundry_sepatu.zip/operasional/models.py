from django.db import models
from django.utils import timezone

# 1. Tabel Daftar Layanan & Harga
class Service(models.Model):
    nama = models.CharField(max_length=100) # Cth: Deep Clean
    harga = models.DecimalField(max_digits=10, decimal_places=0) # Cth: 50000
    durasi_hari = models.IntegerField(default=3) # Estimasi selesai
    
    def __str__(self):
        return f"{self.nama} - Rp {self.harga}"

# 2. Tabel Order (Nota)
class Order(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Baru Masuk'),
        ('PROCESS', 'Sedang Dikerjakan'),
        ('READY', 'Selesai / Siap Ambil'),
        ('COMPLETED', 'Sudah Diambil'),
    ]

    nama_pelanggan = models.CharField(max_length=100)
    whatsapp = models.CharField(max_length=15, help_text="Contoh: 08123456789")
    tanggal_masuk = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    
    # Kita bikin ID unik otomatis nanti
    
    def __str__(self):
        return f"{self.nama_pelanggan} ({self.status})"

# 3. Tabel Item Sepatu (Detail per pasang)
class OrderItem(models.Model):
    # Ini yang menghubungkan Sepatu ke Notanya (Relasi)
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    
    service = models.ForeignKey(Service, on_delete=models.PROTECT)
    merk_sepatu = models.CharField(max_length=50) # Cth: Nike Air Jordan
    warna = models.CharField(max_length=50)
    catatan = models.TextField(blank=True, help_text="Cacat awal/Request khusus")
    
    # Foto Wajib (Liability)
    foto_sebelum = models.ImageField(upload_to='foto_sepatu/before/')
    foto_sesudah = models.ImageField(upload_to='foto_sepatu/after/', blank=True, null=True)
    
    def __str__(self):
        return f"{self.merk_sepatu} - {self.service.nama}"