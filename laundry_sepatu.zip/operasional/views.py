from django.shortcuts import render, redirect, get_object_or_404
from .models import Order
from .forms import OrderForm, OrderItemForm

# 1. Dashboard: Lihat list cucian aktif
def dashboard(request):
    # Ambil order yang statusnya BUKAN 'COMPLETED' (sudah diambil)
    orders = Order.objects.exclude(status='COMPLETED').order_by('-tanggal_masuk')
    return render(request, 'dashboard.html', {'orders': orders})

# 2. Tambah Order: Halaman input order baru
def tambah_order(request):
    if request.method == 'POST':
        # Kalau tombol "Simpan" ditekan
        form_order = OrderForm(request.POST)
        form_item = OrderItemForm(request.POST, request.FILES) # Ada FILES karena upload foto

        if form_order.is_valid() and form_item.is_valid():
            # Simpan data Order (Customer) dulu
            order = form_order.save()
            
            # Simpan data Item (Sepatu), tapi hubungkan ke Order tadi
            item = form_item.save(commit=False)
            item.order = order
            item.save()
            
            return redirect('dashboard') # Balik ke dashboard setelah simpan
    else:
        # Kalau baru buka halaman (belum isi apa-apa)
        form_order = OrderForm()
        form_item = OrderItemForm()

    return render(request, 'tambah_order.html', {
        'form_order': form_order,
        'form_item': form_item
    })

def detail_order(request, order_id):
    # Cari order berdasarkan ID, kalau gak ada kasih error 404
    order = get_object_or_404(Order, id=order_id)
    
    if request.method == 'POST':
        # UPDATE STATUS UTAMA
        status_baru = request.POST.get('status')
        if status_baru:
            order.status = status_baru
            order.save()
            
        # UPDATE FOTO AFTER (Looping karena item bisa lebih dari 1)
        # Kita cek setiap item di order ini
        for item in order.items.all():
            file_foto = request.FILES.get(f'foto_after_{item.id}') # Ambil file dari input
            if file_foto:
                item.foto_sesudah = file_foto
                item.save()
        
        return redirect('detail_order', order_id=order.id) # Refresh halaman

    return render(request, 'detail_order.html', {'order': order})

# 4. Halaman Cetak Struk
def cetak_struk(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    
    # HITUNG TOTAL MANUAL (Biar gak 0)
    total = 0
    for item in order.items.all():
        total += item.service.harga
    
    # Kita kirim variabel 'total_hitung' ke template
    return render(request, 'cetak_struk.html', {
        'order': order, 
        'total_hitung': total
    })